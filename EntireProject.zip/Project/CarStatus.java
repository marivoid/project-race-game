import java.io.Serializable;

public class CarStatus implements Serializable{
   private final long serialVersionUID = 04L;
   private int xPos;
   private int yPos;
   private String color;
   private String name;
   private int carRot;
   private int index=-1;
   

   //Constructor
   public CarStatus(int index, String name, String color, int xPos, int yPos, int carRot){
      this.index = index;
      this.name = name;
      this.color = color;
      this.xPos = xPos;
      this.yPos = yPos;
      this.carRot = carRot;
      
   
   }//end of constructor

   public String getName(){
      return name;
   }
   public int getIndex(){
      return this.index;
   }
   
   public String getColor(){
      return color;
   }
   
   public int getxPos(){
      return xPos;
   }

   public int getyPos(){
      return yPos;
   }
   
   public int getCarRot(){
      return carRot;
   }
  
   public void setName(String name){
      this.name = name;
   }
   
   public void setColor(String color){
      this.color = color;
   }
   
   public void setXPos(int xPos){
      this.xPos = xPos;
   }
   
   public void setYPos(int yPos){
      this.yPos = yPos;
   }
   
   public void setCarRot(int carRot){
      this.carRot = carRot;
   }
   
   public String toString(){
      return this.name + " " + this.color + " " + this.xPos + " " + this.yPos + " " + this.carRot;
   }
   
  
}//end of Car class