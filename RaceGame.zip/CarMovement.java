import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.application.*;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.image.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.*;
import javafx.scene.text.*;
import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.stage.*;
import javafx.geometry.*;
import javafx.animation.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.awt.Color;

import java.net.*;
import java.io.*;
import java.util.*;


//XML DOM PARSER
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.OutputKeys;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import java.io.File;
import javax.xml.parsers.*;
import javax.xml.xpath.*;
import org.xml.sax.*;


/** 
 * Game2DSTARTER with JavaFX and Threads
   Valentines edition
*/

public class CarMovement extends Application implements EventHandler<ActionEvent>{
   /**
   *  All global attribues used for this program
   */
   
   private Stage stage;
   private Scene scene;
   private VBox root;
   
   private boolean upPressed = false;
   private boolean downPressed = false;
   private boolean rightPressed = false;
   private boolean leftPressed = false;
   
   private Button btnStart = new Button("Start");
   private Label lblScore = new Label("Lap count ");
   
   private MenuBar mBar = new MenuBar();
   private Menu cars = new Menu("Cars");
   private Menu about = new Menu("About");
   
   private int counter = 0;
   
   private MenuItem miTwo = new MenuItem("Two cars");
   private MenuItem miThree = new MenuItem("Three cars");
   private MenuItem miFour = new MenuItem("Four cars");
   
   private MenuItem miMore = new MenuItem("More");
   private MenuItem miExit = new MenuItem("Exit"); 
   
   private TextField tfCar1 = new TextField(counter + "/5");
   private TextField tfCar2 = new TextField(counter + "/5");
   private TextField tfCar3 = new TextField(counter + "/5");
   private TextField tfCar4 = new TextField(counter + "/5");
   
   private Label lblCar1 = new Label("Car 1:");
   private Label lblCar2 = new Label("Car 2:");
   private Label lblCar3 = new Label("Car 3:");
   private Label lblCar4 = new Label("Car 4:");
   
   ArrayList<CarRacer> racerList = new ArrayList<CarRacer>();
   
   /**
   *  Socket attribute
   */
   public static final int SERVER_PORT = 32001;
   private Socket socket = null;
   
   /**
   *  IO attributes
   */
   private ObjectInputStream ois = null;
   private ObjectOutputStream oos = null;
   
   BufferedImage rgbChecker=null;
   
   private static String[] args;
   
   private final static String ICON_IMAGE = "CarSprite1.png";  // file with icon for a racer
   private final static String ICON_IMAGE2 = "CarSprite2.png";
   private final static String ICON_IMAGE3 = "CarSprite3.png";
   private final static String ICON_IMAGE4 = "CarSprite4.png";
   
   private int iconWidth;                       // width (in pixels) of the icon
   private int iconHeight;                      // height (in pixels) or the icon
   //private CarRacer racer = null;               // array of racers
   private Image carImage =  null;
   
   private double carDirectionSpeed=0;
   private double carSteeringAngle=0;
   private double carSpeedOnStreet=10;
   
   private int uniqueCarIndex=-1;

   private AnimationTimer timer;                // timer to control animation
   
   // main program
   public static void main(String [] _args) {
      args = _args;
      launch(args);
   }
   
   /**
   * start() method, called via launch
   */ 
   public void start(Stage _stage) {
      // stage seteup
      stage = _stage;
      stage.setTitle("Race Project");
      stage.setOnCloseRequest(
         new EventHandler<WindowEvent>() {
            public void handle(WindowEvent evt) {
               System.exit(0);
            }
         });
      
      // root pane
      root = new VBox(mBar);
      
      cars.getItems().addAll(miTwo, miThree, miFour);
      about.getItems().addAll(miMore, miExit);
      
      mBar.getMenus().addAll(cars, about);
      
      //adding anything to the gui messes up the rgbChecker
      
      
      FlowPane fpTop = new FlowPane(10,10);
      fpTop.setAlignment(Pos.CENTER);
      lblScore.setPrefHeight(50);
      Font currentFont = lblScore.getFont();
      lblScore.setFont(Font.font("Verdana", 22));;
      fpTop.getChildren().add(lblScore);
      
      //root.getChildren().add(fpTop);
      
      FlowPane fpBtm = new FlowPane(10,10);
      fpBtm.setAlignment(Pos.CENTER);
      tfCar1.setPrefWidth(70);
      tfCar1.setPrefHeight(60);
      tfCar1.setFont(Font.font("Verdana", 22));
      lblCar1.setFont(Font.font("Verdana", 22));
      
      tfCar2.setPrefWidth(70);
      tfCar2.setPrefHeight(60);
      tfCar2.setFont(Font.font("Verdana", 22));
      lblCar2.setFont(Font.font("Verdana", 22));
      
      tfCar3.setPrefWidth(70);
      tfCar3.setPrefHeight(60);
      tfCar3.setFont(Font.font("Verdana", 22));
      lblCar3.setFont(Font.font("Verdana", 22));
      
      tfCar4.setPrefWidth(70);
      tfCar4.setPrefHeight(60);
      tfCar4.setFont(Font.font("Verdana", 22));
      lblCar4.setFont(Font.font("Verdana", 22));
      
      tfCar1.setDisable(true);
      tfCar2.setDisable(true);
      tfCar3.setDisable(true);
      tfCar4.setDisable(true);
      
      fpBtm.getChildren().addAll(lblCar1, tfCar1, lblCar2, tfCar2, lblCar3, tfCar3, lblCar4, tfCar4);
      
      //root.getChildren().add(fpBtm);
      
      miTwo.setOnAction(this);
      miThree.setOnAction(this);
      miFour.setOnAction(this);
      
      miMore.setOnAction(this);
      miExit.setOnAction(this);
                 
      // create an array of Racers (Panes) and start
      CarRacer connector = new CarRacer();
      connector.doConnect();
      
        
      initializeScene();
      
   }//end of START
   
   
   /**
   *  Handles methods once menu item is selected
   */
   public void handle(ActionEvent ae){
      
      String text = "";
      
      if(ae.getSource() instanceof MenuItem){
         MenuItem mi = (MenuItem)ae.getSource();
         text = mi.getText();
      }
      else 
         return;
      
      switch(text){
         case "More":
            Alert alert = new Alert(AlertType.INFORMATION);
            alert.setTitle("Race Game");
            alert.setHeaderText("Info about the game:");
            alert.setContentText("Every car must complete 5 circles.\nYou can play with minimum 2 cars.\nThe first to reach 5/5 wins!\nDirt slows you down.\nGood luck!");
            alert.showAndWait();
            break;  
            
         case "Exit":
            System.exit(0);
            break;
         
         case "Two cars":
            doTwo();
            break;
            
         case "Three cars":
            doThree();
            break;
            
         case "Four cars":
            doFour();
            break;
      }
      
   }

   /**
   * Initializes the Scene of the GUI
   */
   public void initializeScene() {
      
      // Make an icon image to find its size
      try {
         carImage = new Image(new FileInputStream(ICON_IMAGE));
      }
      catch(Exception e) {
         System.out.println("Exception: " + e);
         System.exit(1);
      }
            
      // Get image size
      iconWidth = (int)carImage.getWidth();
      iconHeight = (int)carImage.getHeight();
      
      //LOAD XML GAME SETTINGS
      XMLSettings xmlWorker = new XMLSettings("GameSettings.txt");
      xmlWorker.writeXML(); //if the file does not exist  
      xmlWorker.readXML();
      
            
      File file= new File("road5.png");
      
      try{
         rgbChecker = ImageIO.read(file);
      }
      catch(IOException ioe){}  
      
      for(CarRacer oneRacer:racerList){
         root.getChildren().add(oneRacer);
      }
      root.setId("pane");
      
          
      // display the window
      scene = new Scene(root, 1200, 800);
      scene.getStylesheets().addAll(this.getClass().getResource("style.css").toExternalForm());
   
      stage.setResizable(false);
      stage.setScene(scene);
      
      stage.show(); 
      
      Alert alert = new Alert(AlertType.INFORMATION);
      alert.setContentText("Welcome to our race game!\nTo chose how many cars you'd like\nsimply press the menu option 'Cars'.\nBest of luck!");
      alert.setHeaderText("Welcome!");
      alert.showAndWait();
      
      System.out.println("Starting race...");
      
      // Use an animation to update the screen
      timer = 
         new AnimationTimer() {
            public void handle(long now) {
              
               for(CarRacer oneRacer:racerList){
                  oneRacer.update();
               }  
            }
         };
      
      // TimerTask to delay start of race for 2 seconds
      TimerTask task = 
         new TimerTask() {
            public void run() { 
               timer.start();
            }
         };
      Timer startTimer = new Timer();
      long delay = 1000L;
      startTimer.schedule(task, delay);
      
         
         //MOVEMENT CODE
      scene.setOnKeyPressed(
         e -> {
            if (e.getCode() == KeyCode.A) {
               carSteeringAngle = -10;
               leftPressed = true;
            }
            
            if (e.getCode() == KeyCode.D) {
               carSteeringAngle = 10;
               rightPressed = true;
            }
            
            if (e.getCode() == KeyCode.S) {
               carDirectionSpeed=-1; // Added 
               downPressed = true;
            }
            
            if (e.getCode() == KeyCode.W) {
               carDirectionSpeed=1;
               upPressed = true;
              
            }
         });
       
      scene.setOnKeyReleased(
         e -> {
            if (e.getCode() == KeyCode.A) {
               carSteeringAngle = 0;
            }
            
            if (e.getCode() == KeyCode.D) {
               carSteeringAngle = 0;
            }
            
            if (e.getCode() == KeyCode.S) {
               //System.out.println("S was released");
               carDirectionSpeed=0;
            }
            
            if (e.getCode() == KeyCode.W) {
               carDirectionSpeed=0;
               upPressed = true;
              
            }
         });
   
   }
   
   /**
   * Creates two cars and places them on the track
   */
   public void doTwo(){
      CarRacer racer = new CarRacer(0,"Racer1","Red",30,405,90);
      racerList.add(racer);
      
      try {
         carImage = new Image(new FileInputStream(ICON_IMAGE2));
      }
      catch(Exception e) {
         System.out.println("Exception: " + e);
         System.exit(1);
      }
      
      CarRacer racer2 = new CarRacer(1, "Racer2","Pink",98,382,90);
      racerList.add(racer2);
            
      for(CarRacer oneRacer:racerList){
         root.getChildren().add(oneRacer);
      }
      root.setId("pane");
   }
   
   
   /**
   * Creates three cars and places them on the track
   */
   public void doThree(){
      CarRacer racer = new CarRacer(0,"Racer1","Red",30,405,90);
      racerList.add(racer);
      
      try {
         carImage = new Image(new FileInputStream(ICON_IMAGE2));
      }
      catch(Exception e) {
         System.out.println("Exception: " + e);
         System.exit(1);
      }
      
      CarRacer racer2 = new CarRacer(1,"Racer2","Pin",65,380,90);
      racerList.add(racer2);
      
      
      try {
         carImage = new Image(new FileInputStream(ICON_IMAGE3));
      }
      catch(Exception e) {
         System.out.println("Exception: " + e);
         System.exit(1);
      }
      
      
      CarRacer racer3 = new CarRacer(2, "Racer3","Blue",100,350,90);
      racerList.add(racer3);
            
      for(CarRacer oneRacer:racerList){
         root.getChildren().add(oneRacer);
        
      }
      root.setId("pane");
   }
   
   
   /**
   * Creates four cars and places them on the track
   */
   public void doFour(){
      CarRacer racer = new CarRacer(0,"Racer1","Red",30,405,90);
      racerList.add(racer);
      
      try {
         carImage = new Image(new FileInputStream(ICON_IMAGE2));
      }
      catch(Exception e) {
         System.out.println("Exception: " + e);
         System.exit(1);
      }
      
      CarRacer racer2 = new CarRacer(1,"Racer2","Pink",53,380,90);
      racerList.add(racer2);
      
      try {
         carImage = new Image(new FileInputStream(ICON_IMAGE3));
      }
      catch(Exception e) {
         System.out.println("Exception: " + e);
         System.exit(1);
      }
      
      CarRacer racer3 = new CarRacer(2,"Racer3","Blue",76,348,90);
      racerList.add(racer3);
      
      try {
         carImage = new Image(new FileInputStream(ICON_IMAGE4));
      }
      catch(Exception e) {
         System.out.println("Exception: " + e);
         System.exit(1);
      }
      
      CarRacer racer4 = new CarRacer(3, "Racer4","Orange",100,317,90);
      racerList.add(racer4);
            
      for(CarRacer oneRacer:racerList){
         root.getChildren().add(oneRacer);
      }
      root.setId("pane");
   }
   
   
   /** 
      Racer creates the race lane (Pane) and the ability to 
      keep itself going (Runnable)
   */
   protected class CarRacer extends Pane {
      private int carIndex=-1;
      private int racePosX=0;          // x position of the racer
      private int racePosY=0;          // x position of the racer
      private int raceROT=0;          // x position of the racer
      private String name;
      private String color;
      private ImageView aPicView;   // a view of the icon ... used to display and move the image
      
           
      //constructors
      public CarRacer(){ 
      
      }
      
      /**
      *  Creates new Car 
      * @param carIndex index of the car
      * @param name name of the car
      * @param color color of the car
      * @param racePosX x coordinates of the car 
      * @param racePosY y coordinates of the car
      * @param raceROT rotation of the car
      */
      public CarRacer(int carIndex,String name, String color, int racePosX, int racePosY, int raceROT) {
         // Draw the icon for the racer
         this.carIndex = carIndex;
         this.racePosX = racePosX;
         this.racePosY = racePosY;
         this.raceROT = raceROT;
         this.name = name;
         this.color = color;
      
         aPicView = new ImageView(carImage);
         this.getChildren().add(aPicView);
         aPicView.setTranslateX(racePosX);
         aPicView.setTranslateY(racePosY);
         aPicView.setRotate(raceROT);
      
         
      }
      
      /**
      * Gets the index of the car.
      * @return this car's index
      */
      public int getCarIndex(){
         return this.carIndex;
      }
      
      /**
      * Sets the positions of this car.
      * @param racePosX x coordinated of the car
      * @param racePosY y coordinated of the car
      * @param raceROT rotation of the car  
      */
      public void setCarPos(int racePosX, int racePosY, int raceROT){
         
         this.racePosX = racePosX;
         this.racePosY = racePosY;
         this.raceROT = raceROT;
      }
      
     /* public int getPosition(){
      return raceP;
      }*/
   
      /** 
         update() method keeps the thread (racer) alive and moving.  
      */
      public void update() {  
            
         double carSpeed = carDirectionSpeed*carSpeedOnStreet;
         
         if(uniqueCarIndex==this.carIndex){
         
            double mnubarSize = mBar.getHeight();
            int pixX = racePosX;
            int pixY = (int)(racePosY + mnubarSize);
         
            if(pixX>=0 && pixY>=0 && pixX< rgbChecker.getWidth()  && pixY < rgbChecker.getHeight()){
            
            //Retrieving contents of a pixel
               int pixel = rgbChecker.getRGB(pixX,pixY);
            
            /////CONVERTING TO RGB   
               Color color = new Color(pixel, true);
            //Retrieving the R G B values
               int red = color.getRed();
               int green = color.getGreen();
               int blue = color.getBlue();
               
               System.out.printf("Coordinates: X: %4d Y: %4d Color: R: %4d G: %4d R: %4d\n", pixX, pixY, red, green, blue);
              
              //if on grass and dirt
               if((red==27 && green==94 && blue==32)||(red==62 && green==39 && blue==35)) carSpeed = carSpeed/2;
               
               //if on dirt
               if((red==78 && green==52 && blue==46)||(red==93 && green==64 && blue==55)) carSpeed = carSpeed/2;
               
               //if on the edges
               if((red==183 && green==28 && blue==28) || (red==255)) carSpeed = carSpeed/2;
               if(blue==210 || blue==179) carSpeed = (carSpeed+30);
               //if(red==27 && green==94 && blue==32) carSpeed = 0;
            }
            
            
         
            double deltaX = carSpeed * Math.cos(raceROT*3.14/180.0);
            racePosX+=deltaX;
         
            double deltaY = carSpeed * Math.sin(raceROT*3.14/180.0);
            racePosY+=deltaY;
         
            double carLength = 5;
            double deltaROT = (carSpeed/carLength)*Math.tan(carSteeringAngle*3.14/180.0) * 30;
            raceROT+=deltaROT;
            
            CarStatus carInfo = new CarStatus(uniqueCarIndex, name,color, racePosX, racePosY, raceROT);
         
            try{
               oos.writeObject(carInfo);
               oos.writeObject("INFO");
               oos.flush();
            
            }
            catch(IOException ioe){
               System.out.println(ioe);
            }
         }
      
         //getting X,Y coordinates of cars
         //System.out.println(this.name +"- X-Pos:" + this.racePosX + "Y-Pos: " + this.racePosY);
         
         //send from here to server
         //fill CarStatus object with retrieved information from constructor
         try{
            Thread.sleep(17);
         }
         catch(InterruptedException ie){}
        
         aPicView.setTranslateX(racePosX);
         aPicView.setTranslateY(racePosY);
         aPicView.setRotate(raceROT);
          
         //waiting for clients
        
        
      }  // end update()
      
      
      /**
      * Connects the clients to the server
      * @throws ClassNotFoundException
      * @throws IOException
      */
      public void doConnect(){
        
        //this isnt really necessary but ok
         TextInputDialog txtInp = new TextInputDialog();
         txtInp.setHeaderText("Enter IP address of server");
         txtInp.setContentText("Server IP: ");
         txtInp.showAndWait();
         
         String IP = txtInp.getResult();
         System.out.println("Connected!");
            
         try{ 
            socket = new Socket(IP, SERVER_PORT);
            ois = new ObjectInputStream(socket.getInputStream());
            oos = new ObjectOutputStream(socket.getOutputStream());
            
            //getting unique index from the server
            uniqueCarIndex = (Integer)ois.readObject();
            System.out.println("Current car index:" +  uniqueCarIndex);
               
            //thread
            ListenerThread lt = new ListenerThread();
            lt.start();     
            
         }
         catch(ClassNotFoundException cnfe){}
         catch(IOException ioe){ 
            System.out.println("IOException in Connect: " + ioe);
         }
      }//end of doConnect()
      
   }  // end inner class Racer
   
   
    /**
      * Represents a listener thread
      * @throws ClassNotFoundException
      * @throws IOException
      */
   class ListenerThread extends Thread{
      public void run(){
         System.out.println("Client listener starts...");
         while(true) {
         
            
            try{
            
               Object obj = ois.readObject();
               
               if(obj instanceof CarStatus) {
                  CarStatus record = (CarStatus) obj;
                  System.out.println(record);
                  for(int i=0;i<racerList.size();i++){
                     if(racerList.get(i).getCarIndex()==record.getIndex()){
                        racerList.get(i).setCarPos(record.getxPos(),record.getyPos(), record.getCarRot()); 
                     }
                  }
                  
               }
            }
            catch(ClassNotFoundException cnfe){
               System.out.println("Exception in ListenerThread: " + cnfe);
            } 
            catch(IOException ioe){
               System.out.println("Exception in ListenerThread: " + ioe);
            }   
         }
      }  
   }//end of listenerthread
   
      //XML Settings
   
   class XMLSettings{
      //game property 
      public String serverName = "127.0.0.1"; //default 
      public int serverPort = 1234; //default
      
      //general
      private String xmlFilePath = "";
      
      public XMLSettings(String filePath){
         this.xmlFilePath = filePath;
      }
      
      private void writeXML(){
         try {
            DocumentBuilderFactory dbFactory =
               DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.newDocument();
            
            //here we create our xml content
            Element rootElement = doc.createElement("GameSettings");
            doc.appendChild(rootElement);
            
            //socket
            Element socket = doc.createElement("Socket");
            rootElement.appendChild(socket);
            
            //add port and server name
            Element port = doc.createElement("port");
            port.appendChild(doc.createTextNode(this.serverPort + "")); 
            socket.appendChild(port);
            
            Element serverIP = doc.createElement("serverIP");
            serverIP.appendChild(doc.createTextNode(this.serverName + "")); 
            socket.appendChild(serverIP);
                   
         
         // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(this.xmlFilePath));
            transformer.transform(source, result);
         
         // Output to console for testing
            StreamResult consoleResult = new StreamResult(System.out);
            transformer.transform(source, consoleResult);
         } 
         catch (Exception e) {
            e.printStackTrace();
         }  
      }//END OF WRITE XML
      
      
            /** 
      * reading game settings from a file
      */
      public void readXML(){
      
         try{
            DocumentBuilderFactory dbfactory= DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = dbfactory.newDocumentBuilder();
            XPathFactory xpfactory = XPathFactory.newInstance();
            XPath path = xpfactory.newXPath();
         
            File f = new File(this.xmlFilePath);
            Document doc = builder.parse(f);
            
            this.serverPort = Integer.parseInt(path.evaluate(
                  "/GameSettings/Socket/port", doc));
                  
            this.serverName = path.evaluate(
                  "/GameSettings/Socket/serverIP", doc);
         
            System.out.println("Read XML:" + this.serverName + ":" + this.serverPort);         
         
         }
         catch(XPathExpressionException xpee){
            System.out.println(xpee);
         }
         catch(ParserConfigurationException pce){
            System.out.println(pce);
         }
         catch(SAXException saxe){
            System.out.println(saxe);
         }
         catch(IOException ioe){
            System.out.println(ioe);
         
         }
      
      }
      
   }//END OF CLASS
    
} // end class CarMovement