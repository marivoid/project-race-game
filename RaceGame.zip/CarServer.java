import javafx.application.*;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.*;
import javafx.scene.text.*;
import javafx.scene.layout.*;
import javafx.stage.*;
import javafx.geometry.*;
import javafx.collections.*;

import java.net.*;
import java.io.*;
import java.util.*;

																								
/** 
 * CarServer class
*/
public class CarServer extends Application implements EventHandler<ActionEvent>{				
   /**
   *  All global attribues used for this program
   */
   
   private Stage stage;
   private Scene scene;
   private VBox root;

   //components
   private Button btnStart = new Button("Start");
   private Button btnConvert = new Button("Convert");
   
   private Label lblIP = new Label("Server IP: ");
   private TextField tfIP = new TextField();

   private Label lblCount = new Label("CarStatus Count: ");
   private TextField tfCount = new TextField();
   
   public ArrayList<ObjectOutputStream> clientList = new ArrayList<ObjectOutputStream>();
   
   
   /**
   *  Socket attribute
   */
   private ServerSocket sSocket = null;
   public static final int SERVER_PORT = 32001;		
   int clientCounter=0;									
   ArrayList<CarStatus> arrayCarStatus = new ArrayList<CarStatus>();								
   
   /**
   * Default constructor, starts the server thread
   */
   public CarServer(){
      
      System.out.println("MThread started...");
      ServerThread serverThread = new ServerThread();
      serverThread.start();
   }
   
   /**
   *  Handles buttons
   */
   public void handle(ActionEvent ae) { 
      String sourceText="";
   
      Button btn1 = (Button)ae.getSource();
      sourceText = btn1.getText();
      switch(sourceText){
      
         case "Start":
            System.out.println("Start pressed");
            ServerThread serverThread = new ServerThread();
            serverThread.start();
            break;
            
         case "Convert" :  
         
            System.out.println("Convert pressed");
                       
      }//end of switch
     
     
   }//end of event handler
   
   /**
   *  Server Thread
      Opens socket, waits for client and accepts clients
      starts Client Thread
   */
   class ServerThread extends Thread{
      public void run(){
         try {
            System.out.println("Start listening..");
            sSocket = new ServerSocket(SERVER_PORT);
         }
         catch(IOException ioe) {
            System.out.println("IO Exception (1): "+ ioe + "\n");
            return;
         }
         
         while(true){
            Socket cSocket = null;
            try {
               System.out.println("Waiting client to connect...");
            // Wait for a connection
               
               cSocket = sSocket.accept();
               System.out.println("Client connected");
            }
            catch(IOException ioe) {
               System.out.println("IO Exception (2): "+ ioe + "\n");
               return;
            }
            //Start client thread
            ClientThread ct = new ClientThread(cSocket, "Client" + clientCounter,clientCounter);
            clientCounter++;
            ct.start();  
         }
      
      }
   }//end of ServerThread
   
   /**
   *  Client Thread
      Receives objects from Client and sends them to other clients, except itself
      @throws Exception 
      @throwsw IOException
   */
   class ClientThread extends Thread{
      private Socket cSocket=null;
      private String cName="";
      private int index=0;
      public ClientThread(Socket _cSocket, String _name, int index){
         this.cSocket = _cSocket;
         this.cName = _name;
         this.index=index;
      }
      public void run(){
         System.out.println(this.cName +" connected");
           // IO attributes
         ObjectInputStream ois = null;
         ObjectOutputStream oos = null;       
         try {
            oos = new ObjectOutputStream(cSocket.getOutputStream());
            clientList.add(oos);
            ois = new ObjectInputStream(cSocket.getInputStream());
            
            oos.writeObject((Integer)index);
            oos.flush();
            
            while(true) {
               Object obj = ois.readObject();
               
               if(obj instanceof CarStatus) {
                  CarStatus record = (CarStatus) obj;
                  System.out.println(record);
                  
                  //send it back to all other clients
                  for(ObjectOutputStream oosOne : clientList){
                     if(oosOne!=oos){
                        oosOne.writeObject(record);
                     }
                  }
                  //oos.writeObject("Success: " + order.toString());
                  oos.flush();
               }
               else if(obj instanceof String) {
                  String command = (String) obj;
                  switch (command.toUpperCase()) {
                     case "INFO":
                        //read
                        System.out.println("received");
                        //ois.readObject();
                        //System.out.println(arrayCarStatus.size());
                        //oos.writeObject(arrayCarStatus.size());
                        break;
                     case "LIST":
                        oos.writeObject(arrayCarStatus);
                        oos.flush();
                        break;
                     
                  }
               
               }
                        
                            
            }
         
                               
         }
         catch(Exception e) {
            System.out.println("Exception opening streams: " + e);
            System.out.println(this.cName+" disconnected");
         }
         
         try{
            oos.close();
            ois.close();
            this.cSocket.close();
         }
         catch(IOException ie){
         }
      
              
      }
   }
   
   
   public static void main(String [] args) {															
      launch(args);
   }
     
    /**
   * start() method, called via launch
   */       
   public void start(Stage _stage){
      stage = _stage;
      stage.setTitle("CarStatus Server");
      stage.setOnCloseRequest(
         new EventHandler<WindowEvent>() {
            public void handle(WindowEvent evt) { System.exit(0); }
         });
          
      btnStart.setOnAction(this);
      btnConvert.setOnAction(this);    
          
      root = new VBox(8);
         
      FlowPane fpButtons = new FlowPane(8,8);
      fpButtons.getChildren().addAll(btnStart,btnConvert);
         
      FlowPane fpIP = new FlowPane(8,8);
      fpIP.getChildren().addAll(lblIP,tfIP);
         
      tfIP.setDisable(true);
         
      FlowPane fpCarStatusCount = new FlowPane(8,8);
      fpCarStatusCount.getChildren().addAll(lblCount,tfCount);
         
      tfCount.setDisable(true);
   
      root.getChildren().addAll(fpButtons,fpIP,fpCarStatusCount);
   
      scene = new Scene(root,475,300);
      stage.setScene(scene);
      stage.show();
         
                  
   }//end of start
                    				                           
                              											
}	// end class																								
					
					
					
